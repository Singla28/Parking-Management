package customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Calendar;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class billname {
	Connection conn;
	PreparedStatement pst;
	
	public billname()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//==========================================
		
		stage=new Stage();
		grd=new GridPane();
		logo=new ImageView(new Image(login.class.getResourceAsStream("billwatcher.png")));
		Calendar cal=Calendar.getInstance();
		cname=new ComboBox<String>();
		df=new DatePicker(LocalDate.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DATE)));
	    dt=new DatePicker(LocalDate.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DATE)));
		tbl=new TableView<history>();
		btnf=new Button("Fetch");
		lablh=new Text("BILL WATCHER");
		labldf=new Text("Date From : ");
		labldf.setFill(Color.BLUE);
		labldf.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		labldt=new Text("Date To : ");
		labldt.setFill(Color.BLUE);
		labldt.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		labla=new Text("Total Amount Received");
		labla.setFill(Color.BLUE);
		labla.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		txta=new TextField();
		txta.setPromptText("Amount is");
		txta.setEditable(true);
		btnf.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		lablh.setFont(Font.font("Free Hand Script",FontWeight.BOLD,36));
		grd.setConstraints(logo, 0, 0, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(logo);
		
		grd.setConstraints(labldf, 0, 1, 1, 1, HPos.LEFT, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labldf);
		
		grd.setConstraints(labldt, 1, 1, 1, 1, HPos.LEFT, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labldt);
		
		grd.setConstraints(df, 0, 2, 1, 1, HPos.RIGHT, VPos.CENTER, null, null, new Insets(0,0,0,0));
		grd.getChildren().add(df);
		
		grd.setConstraints(dt, 1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(dt);
		
		grd.setConstraints(btnf, 0, 3, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnf);
		
		grd.setConstraints(labla, 0, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labla);
		
		grd.setConstraints(txta, 1, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txta);
		
		grd.setConstraints(tbl, 0, 5, 4, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(tbl);
		grd.setStyle("-fx-background-color:ALICEBLUE");
		TableColumn<history, String> col1=new TableColumn<>("Vehicle no.");
		col1.setCellValueFactory(new PropertyValueFactory<>("vno"));
		
		TableColumn<history, String> col2=new TableColumn<>("Bill");
		col2.setCellValueFactory(new PropertyValueFactory<>("bill"));
		
		TableColumn<history, String>col3=new TableColumn<>("Wheeler");
		col3.setCellValueFactory(new PropertyValueFactory<>("wheeler"));
		col3.setMinWidth(100);
		
		TableColumn<history, String>col7=new TableColumn<>("Mobile No");
		col7.setCellValueFactory(new PropertyValueFactory<>("mno"));
		col7.setMinWidth(100);
		grd.setAlignment(Pos.CENTER);
		tbl.getColumns().addAll(col1,col7,col2,col3);
		
		btnf.setOnAction(e->tbl.setItems(dofetchdate()));
		
		Scene scene =new Scene(grd,800,700);
		stage.setScene(scene);
		stage.show();

				
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	GridPane grd;
	Text lablh,labldf,labla,labldt;
	TableView<history> tbl;
	ComboBox<String> cname;
	Button btnf,btnfr;
	TextField txta;
	DatePicker df,dt;
	ImageView logo;
	Stage stage;
	public void start() throws Exception {
		// TODO Auto-generated method stub
			}
	ObservableList<history> dofetchdate()
	{
		float sum=0.0f;
		ObservableList<history> lst=FXCollections.observableArrayList();
		LocalDate local=df.getValue();
		java.sql.Date d=java.sql.Date.valueOf(local);
		LocalDate lacal1=dt.getValue();
		java.sql.Date d1=java.sql.Date.valueOf(lacal1);
		System.out.println(local+"Year"+local.getYear()+"Month"+local.getMonth());
		try {
			pst=conn.prepareStatement("select * from history where indate=? or outdate=?");
			pst.setDate(1, d);
			pst.setDate(2, d1);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				float b=rs.getFloat("bill");
				sum=sum+b;
				history ref=new history(rs.getString("vno"),rs.getString("mno"),rs.getString("wheeler"),rs.getInt("status"),rs.getFloat("bill"),rs.getDate("indate"),rs.getDate("outdate"));
				lst.add(ref);
			}
			txta.setText(""+sum);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
	}
}
