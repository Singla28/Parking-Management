package customer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Calendar;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class parkinghistory {
	Connection conn;
	PreparedStatement pst;
	public parkinghistory()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//===================================
		
		stage=new Stage();
		grd=new GridPane();
		logo=new ImageView(new Image(login.class.getResourceAsStream("parkinghistory.png")));
	    vbox=new VBox();
	    hbox=new HBox();
	    Calendar cal=Calendar.getInstance();
	    df=new DatePicker(LocalDate.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DATE)));
	    dt=new DatePicker(LocalDate.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DATE)));
	    labl=new Text("Vehicle no");
	    labl.setFill(Color.BLUE);
		labl.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		txt=new TextField();
		btns=new Button("Search");
		btnee=new Button("Export To Excel");
		lablh=new Text("Parking History");
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,29));
		labldf=new Text("Date From");
		labldf.setFill(Color.BLUE);
		labldf.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		labldt=new Text("Date To");
		labldt.setFill(Color.BLUE);
		labldt.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		btnf=new Button("Fetch");
		tw=new RadioButton("2-Wheeler");
		fw=new RadioButton("4-Wheeler");
		tw.setTextFill(Color.BLUE);
		fw.setTextFill(Color.BLUE);
		btnfb=new Button("Fetch");
		ToggleGroup tg=new ToggleGroup();
		tw.setToggleGroup(tg);
		fw.setToggleGroup(tg);
		tbl=new TableView<>();
		btns.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnf.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnfb.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnee.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		hbox.getChildren().addAll(labl,txt,btns);
		
		TableColumn<history, String>col1=new TableColumn<>("Vehicle No.");
		col1.setCellValueFactory(new PropertyValueFactory<>("vno"));
		col1.setMinWidth(100);
		
		TableColumn<history, String>col2=new TableColumn<>("Mobile No.");
		col2.setCellValueFactory(new PropertyValueFactory<>("mno"));
		col2.setMinWidth(100);
		
		TableColumn<history, String>col3=new TableColumn<>("Wheeler");
		col3.setCellValueFactory(new PropertyValueFactory<>("wheeler"));
		col3.setMinWidth(100);
		
		TableColumn<history, String>col5=new TableColumn<>("Indate");
		col5.setCellValueFactory(new PropertyValueFactory<>("indate"));
		col5.setMinWidth(100);
		grd.setStyle("-fx-background-color:ALICEBLUE");
		TableColumn<history, String>col6=new TableColumn<>("Outdate");
		col6.setCellValueFactory(new PropertyValueFactory<>("outdate"));
		col6.setMinWidth(100);

		tbl.getColumns().addAll(col1,col2,col3,col5,col6);
		//txt.setMaxSize(100, 50);
		
		hbox1=new HBox();
		hbox2=new HBox();
		hbox3=new HBox();
		hbox4=new HBox();
		
		hbox1.getChildren().addAll(labldf,df,btnf);
		hbox2.getChildren().addAll(labldt,dt);
		hbox3.getChildren().addAll(tw,fw,btnfb);
		vbox.getChildren().addAll(hbox,hbox1,hbox2,hbox3,hbox4,tbl);
		
		hbox.setMargin(labl, new Insets(20));
		hbox.setMargin(txt, new Insets(18));
		hbox.setMargin(btns, new Insets(18));
		hbox1.setMargin(labldf, new Insets(20));
		hbox1.setMargin(df, new Insets(18));
		hbox2.setMargin(labldt, new Insets(18));
		hbox2.setMargin(dt, new Insets(20));
		hbox2.setMargin(btnf, new Insets(20));
		hbox3.setMargin(tw, new Insets(20));
		hbox3.setMargin(fw, new Insets(20));
		hbox3.setMargin(btnfb, new Insets(20));
		
		btns.setOnAction(e->tbl.setItems(getsomerows()));
		btnf.setOnAction(e->tbl.setItems(dofetchdate()));
		btnfb.setOnAction(e->tbl.setItems(getrowsbtn()));
		
		grd.setConstraints(logo, 0, 0, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(logo);
		
		grd.setConstraints(vbox, 1, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(vbox);
		
		grd.setConstraints(btnee, 1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnee);
		btnee.setOnAction(e->{
			try {
				gethistrows();
				doexcel();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		Scene scene=new Scene(grd,700,650);
		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	Stage stage;
	GridPane grd;
	RadioButton tw,fw;
	TableView<history> tbl;
	TextField txt;
	Text labl,labldf,labldt,lablh;
	Button btns,btnf,btnfb,btnee;
	VBox vbox;
	HBox hbox,hbox1,hbox2,hbox3,hbox4;
	DatePicker df,dt;
	ImageView logo;
	public void start() throws Exception {
		// TODO Auto-generated method stub
		
	}
	void doexcel() throws Exception
	{
		Writer writer=null;
		
		try {
			File file=new File("E:\\CarParking\\Userss.csv");
			writer=new BufferedWriter(new FileWriter(file));
			String text="Vehicle No.,Mobile No.,Indate,Outdate\n";
			writer.write(text);
			for(history user : ary)
			{
				text=user.getVno()+","+user.getMno()+","+user.getIndate()+","+user.getOutdate()+"\n";
				writer.write(text);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			writer.flush();
			writer.close();
		}
	}
	ObservableList<history> ary=FXCollections.observableArrayList();
	ObservableList<history> gethistrows()
	{
		String rbtn="";
		if(tw.isSelected())
		{
			rbtn="2-Wheeler";
		}
		if(fw.isSelected())
		{
			rbtn="4-Wheeler";
		}
		ObservableList<history> lst=FXCollections.observableArrayList();
		LocalDate local=df.getValue();
		java.sql.Date d=java.sql.Date.valueOf(local);
		LocalDate lacal1=dt.getValue();
		java.sql.Date d1=java.sql.Date.valueOf(lacal1);
		ary.clear();
		try {
			pst=conn.prepareStatement("select * from history ");
			// where vno like '%"+txt.getText()+"%' or indate=? or outdate=? or wheeler=?
//			pst.setDate(1, d);
//			pst.setDate(2, d1);
//			pst.setString(3,rbtn);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ary.add(new history(rs.getString("vno"),rs.getString("mno"),rs.getString("wheeler"),rs.getInt("status"),rs.getFloat("bill"),rs.getDate("indate"),rs.getDate("outdate")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ary;
	}
	
	ObservableList<history> dofetchdate()
	{
		ObservableList<history> lst=FXCollections.observableArrayList();
		LocalDate local=df.getValue();
		java.sql.Date d=java.sql.Date.valueOf(local);
		LocalDate lacal1=dt.getValue();
		java.sql.Date d1=java.sql.Date.valueOf(lacal1);
		System.out.println(local+"Year"+local.getYear()+"Month"+local.getMonth());
		try {
			pst=conn.prepareStatement("select * from history where indate=? and outdate=?");
			pst.setDate(1, d);
			pst.setDate(2, d1);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				history ref=new history(rs.getString("vno"),rs.getString("mno"),rs.getString("wheeler"),rs.getInt("status"),rs.getFloat("bill"),rs.getDate("indate"),rs.getDate("outdate"));
				lst.add(ref);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
	}
	ObservableList<history> getsomerows()
	{
		ObservableList<history> lst=FXCollections.observableArrayList();
		try {
			pst=conn.prepareStatement("select * from history where vno like '%"+txt.getText()+"%'");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				history ref=new history(rs.getString("vno"),rs.getString("mno"),rs.getString("wheeler"),rs.getInt("status"),rs.getFloat("bill"),rs.getDate("indate"),rs.getDate("outdate"));
				lst.add(ref);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
	}
	ObservableList<history> getrowsbtn()
	{
		String rbtn="";
		if(tw.isSelected())
		{
			rbtn="2-Wheeler";
		}
		if(fw.isSelected())
		{
			rbtn="4-Wheeler";
		}
		ObservableList<history> lst=FXCollections.observableArrayList();
		try {
			pst=conn.prepareStatement("select * from history where wheeler=?");
			pst.setString(1, rbtn);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				history ref=new history(rs.getString("vno"),rs.getString("mno"),rs.getString("wheeler"),rs.getInt("status"),rs.getFloat("bill"),rs.getDate("indate"),rs.getDate("outdate"));
				lst.add(ref);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lst;
	}
}
