package customer;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
//import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class login extends Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	TextField textu;
	PasswordField textp;
	GridPane grd;
	Text lblh,lblu,lblp;
	Button btnl;
	ImageView logo,logo1,logo2;
	@Override
	public void start(Stage stage) throws Exception {
		grd=new GridPane();
		//grd.setPadding(new Insets(50));
		textu=new TextField();
		textp= new PasswordField();
	    logo=new ImageView(new Image(login.class.getResourceAsStream("park1.png")));
	    logo1=new ImageView(new Image(login.class.getResourceAsStream("login1.png")));
	    logo2=new ImageView(new Image(login.class.getResourceAsStream("carparklogin1.png")));
		logo.setFitWidth(100);
		logo.setFitHeight(100);
		
		logo1.setFitWidth(200);
		logo1.setFitHeight(50);
		
		lblh=new Text("Login");
		lblu=new Text("User ID :");
		lblp=new Text("Password");
		lblu.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,22));
		lblp.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,22));
		lblu.setFill(Color.BLUE);
		lblp.setFill(Color.BLUE);
		textu.setPromptText("Name/ID");
		btnl=new Button("LOGIN");
		btnl.setTextFill(Color.BLUE);
		btnl.setFont(Font.font("Arial",FontWeight.BOLD,20));
		textp.setPromptText("Password :");
		grd.setStyle("-fx-background-color:ALICEBLUE");
		//btnl.setPrefSize(30, 40);
		grd.setAlignment(Pos.CENTER);
		lblh.setFont(Font.font("Arial",FontWeight.BOLD,20));
		lblh.setFill(Color.BLUE);
		btnl.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		grd.setConstraints(logo, 0, 0, 1, 1, HPos.CENTER, VPos.CENTER, null, null,new Insets(20));
		grd.getChildren().add(logo);
		logo2.setFitHeight(300);
		logo2.setFitWidth(200);
		grd.setConstraints(logo2, 1, 1, 1, 5, HPos.CENTER, VPos.CENTER, null, null,new Insets(20));
		grd.getChildren().add(logo2);
		
		grd.setConstraints(logo1, 1, 0, 1, 1, HPos.LEFT, VPos.CENTER, null, null,new Insets(20));
		grd.getChildren().add(logo1);
		
		grd.setConstraints(lblu, 0, 1, 1, 1, HPos.LEFT, VPos.CENTER, null, null,new Insets(20));
		grd.getChildren().add(lblu);
				
		grd.setConstraints(textu, 0, 2, 1, 1, HPos.RIGHT, VPos.CENTER, null, null,new Insets(20));
		grd.getChildren().add(textu);
		
		grd.setConstraints(lblp, 0, 3, 1, 1, HPos.LEFT, VPos.CENTER, null, null,new Insets(20));
		grd.getChildren().add(lblp);
		
		grd.setConstraints(textp, 0, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null,new Insets(20));
		grd.getChildren().add(textp);
		
		grd.setConstraints(btnl, 0, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null,new Insets(20));
		grd.getChildren().add(btnl);
		ImageView icon1=new ImageView(new Image(login.class.getResourceAsStream("favicon.png")));
		btnl.setGraphic(icon1);
		btnl.setOnAction(e->{
			textu.setStyle("-fx-background-color:WHITE; -fx-border:BLUE");

			if(textu.getText().contentEquals(""))
			{
				textu.setStyle("-fx-background-color:RED; -fx-border:BLUE");
			}
			textp.setStyle("-fx-background-color:WHITE; -fx-border:BLUE");

			if(textp.getText().contentEquals(""))
			{
				textp.setStyle("-fx-background-color:RED; -fx-border:BLUE");
			}
			
			if(textu.getText().contentEquals("Admin") && textp.getText().contentEquals("1234"))
			{
				String ab=SST_SMS.bceSunSoftSend("8629010235", "You are Logged in");
				System.out.println("Message Sent");
				System.out.println(ab);
				DashBoard obj=new DashBoard();
			}
			else
			{
				Alert alert=new Alert(AlertType.INFORMATION);
				alert.setContentText("Invalid ID");
				alert.show();
			}
			
		});
		Scene scene=new Scene(grd,500,500);
		stage.setScene(scene);
		stage.show();
	}
	
}
