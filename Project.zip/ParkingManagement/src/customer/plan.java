package customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class plan {
	Connection conn;
	PreparedStatement pst;
	public plan()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// ====================
		grd=new GridPane();
		stage=new Stage();
		logo=new ImageView(new Image(login.class.getResourceAsStream("parkingplan.png")));
		tw=new RadioButton("2-Wheeler");
		fw=new RadioButton("4-Wheeler");
		txts=new TextField();
		txts.setPromptText("Enter Slots");
		lablh=new Text("PARKING PLAN");
		lablf=new Text("Floors");
		lablf.setFill(Color.BLUE);
		lablf.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		labls=new Text("Slots");
		labls.setFill(Color.BLUE);
		labls.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablt=new Text("Type");
		lablt.setFill(Color.BLUE);
		lablt.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		btns=new Button("Save");
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,22));
		grd.setAlignment(Pos.TOP_CENTER);
		grd.setVgap(20);
		grd.setPadding(new Insets(20));
		floor=new ComboBox<Integer>();
		grd.setStyle("-fx-background-color:ALICEBLUE");
		btns.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		ArrayList<Integer> lst=new ArrayList<Integer>();
		for(int i=1;i<10;i++)
		{
			lst.add(i);
		}
		floor.getItems().addAll(lst);
		floor.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		//floor.setEditable(true);
		ToggleGroup tg=new ToggleGroup();
		tw.setToggleGroup(tg);
		fw.setToggleGroup(tg);
		tw.setTextFill(Color.BLUE);
		fw.setTextFill(Color.BLUE);
		logo.setFitWidth(400);
		grd.setConstraints(logo, 0, 0, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10,0,0,20));
		grd.getChildren().add(logo);
		
		grd.setConstraints(lablf, 0, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(lablf);
		
		grd.setConstraints(floor, 1, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(floor);
		
		grd.setConstraints(labls, 0, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(labls);
		
		grd.setConstraints(txts, 1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(txts);
		
		grd.setConstraints(lablt, 0, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(lablt);
		
		grd.setConstraints(tw, 1, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(tw);
		
		grd.setConstraints(fw, 2, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(fw);
		
		grd.setConstraints(btns, 0, 4, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(btns);
		
		
		
		btns.setOnAction(e->dosave());
		
		
		Scene scene=new Scene(grd,500,500);
		stage.setScene(scene);
		stage.show();
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	RadioButton tw,fw;
	TextField txts;
	Text lablh,lablf,labls,lablt;
	Button btns,btnc;
	ComboBox<Integer> floor;
	GridPane grd;
	Stage stage;
	ImageView logo;
	public void start() throws Exception {
		// TODO Auto-generated method stub
		
	}
	void dosave()
	{
		try {
			String rbtn="";
			if(tw.isSelected()==true)
			{
				rbtn="2-Wheeler";
			}
			if(fw.isSelected()==true)
			{
				rbtn="4-Wheeler";
			}
			pst=conn.prepareStatement("insert into plan values (?,?,?,?)");
			pst.setInt(1, floor.getSelectionModel().getSelectedItem());
			pst.setString(2, txts.getText());
			int booked=0;
			pst.setInt(3, booked);
			pst.setString(4, rbtn);
			int k=pst.executeUpdate();
			if(k==0)
			System.out.println("Record Saved..");
			else
			{
				Alert alert=new Alert(AlertType.INFORMATION);
				alert.setContentText("Floor has been updated");
				alert.show();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}
