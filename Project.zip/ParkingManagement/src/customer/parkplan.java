package customer;

public class parkplan {
	int floor;
	String tslot;
	int booked;
	String rbtn;
	public parkplan(int floor,String tslot,int booked,String rbtn)
	{
		this.floor=floor;
		this.tslot=tslot;
		this.booked=booked;
		this.rbtn=rbtn;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public String getTslot() {
		return tslot;
	}
	public void setTslot(String tslot) {
		this.tslot = tslot;
	}
	public int getBooked() {
		return booked;
	}
	public void setBooked(int booked) {
		this.booked = booked;
	}
	public String getRbtn() {
		return rbtn;
	}
	public void setRbtn(String rbtn) {
		this.rbtn = rbtn;
	}

}
