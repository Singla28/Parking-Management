package customer;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class printbill extends Application {

	Connection conn;
	PreparedStatement pst;
	printbill(String b,String i,String o,String w,String v)
	{
		System.out.println(b +" "+i +" " +o +" " +w +" "+v);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	GridPane grd=new GridPane();
	Text lablh,lablv,labli,lablo,labla,txtv,txti,txto,txta;
	Button btnp;
	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		lablh=new Text("BILL");
		lablv=new Text("Vehicle No. :");
		labli=new Text("Indate :");
		lablo=new Text("Outdate :");
		labla=new Text("Amount :");
		txtv=new Text();
		txti=new Text();
		txto=new Text();
		txta=new Text();
		btnp=new Button("Print");
		grd.setAlignment(Pos.CENTER);
		grd.setConstraints(lablh,0, 0, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablh);
		
		grd.setConstraints(lablv,0, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablv);
		
		grd.setConstraints(txtv,1, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtv);
		
		grd.setConstraints(labli,0, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labli);
		
		grd.setConstraints(txti,1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txti);
		
		grd.setConstraints(lablo,0, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablo);
		
		grd.setConstraints(txto,1, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txto);
		
		grd.setConstraints(labla,0, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labla);
		
		grd.setConstraints(txta,1, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txta);
		
		grd.setConstraints(btnp,0, 5, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnp);
		
		Scene scene=new Scene(grd,500,500);
		stage.setScene(scene);
		stage.show();
	}

}
