package customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class presentstatus {

	Connection conn;
	PreparedStatement pst;
	
	public presentstatus()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//====================================================
		
		stage=new Stage();
		grd=new GridPane();
		logo=new ImageView(new Image(login.class.getResourceAsStream("presentstatus.png")));
		lablh=new Text("Present Status");
		tbl=new TableView<>();
		grd.setStyle("-fx-background-color:ALICEBLUE");
		TableColumn<history, String>col1=new TableColumn<>("Vehicle No.");
		col1.setCellValueFactory(new PropertyValueFactory<>("vno"));
		col1.setMinWidth(100);
		
		TableColumn<history, String>col2=new TableColumn<>("Mobile No.");
		col2.setCellValueFactory(new PropertyValueFactory<>("mno"));
		col2.setMinWidth(100);
		
		TableColumn<history, String>col3=new TableColumn<>("Wheeler");
		col3.setCellValueFactory(new PropertyValueFactory<>("wheeler"));
		col3.setMinWidth(100);
		
		TableColumn<history, String>col4=new TableColumn<>("Indate");
		col4.setCellValueFactory(new PropertyValueFactory<>("indate"));
		col4.setMinWidth(100);
		
		tbl.setItems(getrows());
		
		tbl.getColumns().addAll(col1,col2,col3,col4);
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,48));

		grd.setConstraints(logo, 0, 0, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(logo);
		
		grd.setConstraints(tbl, 0, 1, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(tbl);
		
		Scene scene =new Scene(grd,550,600);
		stage.setScene(scene);
		stage.show();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	}
	GridPane grd;
	Text lablh;
	TableView<history> tbl;
	ImageView logo;
	Stage stage;

	public void start() throws Exception {
		// TODO Auto-generated method stub
		
	}
	ObservableList<history> getrows()
	{
		ObservableList<history> lst=FXCollections.observableArrayList();
		try {
			pst=conn.prepareStatement("select * from history where status=1");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				history ref=new history(rs.getString("vno"),rs.getString("mno"),rs.getString("wheeler"),rs.getInt("status"),rs.getFloat("bill"),rs.getDate("indate"),rs.getDate("outdate"));
				lst.add(ref);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
	}
}
