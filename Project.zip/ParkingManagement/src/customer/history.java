package customer;

import java.util.Date;

public class history {
	String vno;
	String mno;
	String wheeler;
	int status;
	Date indate,outdate;
	float bill;
	public history() {}
	public history(String vno,String mno,String wheeler,int status,float bill,Date indate,Date outdate)
	{
		this.vno=vno;
		this.mno=mno;
		this.wheeler=wheeler;
		this.status=status;
		this.indate=indate;
		this.outdate=outdate;
		this.bill=bill;
	}
	public float getBill() {
		return bill;
	}
	public void setBill(float bill) {
		this.bill = bill;
	}
	public Date getIndate() {
		return indate;
	}
	public void setIndate(Date indate) {
		this.indate = indate;
	}
	public Date getOutdate() {
		return outdate;
	}
	public void setOutdate(Date outdate) {
		this.outdate = outdate;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getWheeler() {
		return wheeler;
	}
	public void setWheeler(String wheeler) {
		this.wheeler = wheeler;
	}
	public String getVno() {
		return vno;
	}
	public String getMno() {
		return mno;
	}
	public void setVno(String vno) {
		this.vno = vno;
	}
	public void setMno(String mno) {
		this.mno = mno;
	}
	
}
