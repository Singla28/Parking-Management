package customer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import com.sun.glass.ui.Cursor;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class DashBoard {
	public DashBoard()
	{
		grd=new GridPane();
		lablh=new Text("DashBoard");
		try {
			img=new ImageView(new Image(new FileInputStream("adding.png")));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
		
		DropShadow ds =new DropShadow();
		try {
			img1=new ImageView(new Image(new FileInputStream("parkpkan.png")));
			img2=new ImageView(new Image(new FileInputStream("vehicleentry.png")));
			img3=new ImageView(new Image(new FileInputStream("exit1.png")));
			img4=new ImageView(new Image(new FileInputStream("search.gif")));
			img5=new ImageView(new Image(new FileInputStream("search1.png")));
			img6=new ImageView(new Image(new FileInputStream("presentstatus.png")));
			img7=new ImageView(new Image(new FileInputStream("planstatus.png")));
			img9=new ImageView(new Image(new FileInputStream("aboutus.png")));
			imageb=new ImageView(new Image(new FileInputStream("Carpark sign.png")));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		logo=new ImageView(new Image(login.class.getResourceAsStream("dashboard.png")));
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,48));
		Circle cir1=new Circle(100,200,80);
		img.setFitHeight(150);
		img.setFitWidth(150);
		img1.setFitHeight(150);
		img1.setFitWidth(150);
		img2.setFitHeight(150);
		img2.setFitWidth(150);
		img3.setFitHeight(150);
		img3.setFitWidth(150);
		img4.setFitHeight(150);
		img4.setFitWidth(150);
		img5.setFitHeight(150);
		img5.setFitWidth(150);
		img6.setFitHeight(150);
		img6.setFitWidth(150);
		img7.setFitHeight(150);
		img7.setFitWidth(150);
		img9.setFitHeight(100);
		img9.setFitWidth(100);
		imageb.setFitHeight(250);
		imageb.setFitWidth(800);
//		grd.setHgap(20);
//		grd.setVgap(50);
		grd.setStyle("-fx-background-color:ALICEBLUE");
		img.setOnMouseClicked(e->{
			addcustomers obj=new addcustomers();
		});
		img1.setOnMouseClicked(e->{
			plan obj1=new plan();
		});
		img2.setOnMouseClicked(e->{
			routine obj2=new routine();
		});
		img3.setOnMouseClicked(e->{
			bill obj3=new bill();
		});
		img4.setOnMouseClicked(e->{
			parkinghistory obj4=new parkinghistory();
		});
		img5.setOnMouseClicked(e->{
			billname obj5=new billname();
		});
		img6.setOnMouseClicked(e->{
			presentstatus obj6=new presentstatus();
		});
		img7.setOnMouseClicked(e->{
			parkplanstatus obj7=new parkplanstatus();
		});
		img9.setOnMouseClicked(e->{
			Aboutus obj8=new Aboutus();
		});
		img1.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img1.setEffect(ds);
			}
			
		});
		img1.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img1.setEffect(null);
			}
			
		});
		
		img2.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img2.setEffect(ds);
			}
			
		});
		img2.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img2.setEffect(null);
			}
			
		});
		
		img.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img.setEffect(ds);
			}
			
		});
		img.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img.setEffect(null);
			}
			
		});
		
		img3.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img3.setEffect(ds);
			}
			
		});
		img3.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img3.setEffect(null);
			}
			
		});
		
		img6.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img6.setEffect(ds);
			}
			
		});
		img6.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img6.setEffect(null);
			}
			
		});
		
		img7.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img7.setEffect(ds);
			}
			
		});
		img7.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img7.setEffect(null);
			}
			
		});
		
		img4.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img4.setEffect(ds);
			}
			
		});
		img4.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img4.setEffect(null);
			}
			
		});
		
		img5.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img5.setEffect(ds);
			}
			
		});
		img5.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img5.setEffect(null);
			}
			
		});
		
		img9.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img9.setEffect(ds);
			}
			
		});
		img9.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				// TODO Auto-generated method stub
				img9.setEffect(null);
			}
			
		});
		grd.setConstraints(logo, 0, 0, 5, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(logo);
		grd.setConstraints(img, 0, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(img);
		grd.setConstraints(img1, 1, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(img1);
		grd.setConstraints(img2, 2, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(img2);
		grd.setConstraints(img3, 3, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(img3);
		grd.setConstraints(img4, 0, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(img4);
		grd.setConstraints(img5, 1, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(img5);
		grd.setConstraints(img6, 2, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(img6);
		grd.setConstraints(img7, 3, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(img7);
		grd.setConstraints(img9, 4, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(0));
		grd.getChildren().add(img9);
		grd.setConstraints(imageb, 0, 2, 4, 1, HPos.LEFT, VPos.TOP, null, null, new Insets(0));
		grd.getChildren().add(imageb);
		//String image = DashBoard.class.getResource("Carpark sign.png").toExternalForm();
//		grd.setStyle("-fx-background-image: imageb; " +
//		           "-fx-background-position: left top bottom; " +
//		           "-fx-background-repeat: stretch;"+ 
//		           "-fx-background-size: 800 550;"
//		           +"-fx-background-margin: 20");
		Stage stage=new Stage();
		Scene scene=new Scene(grd,1000,800);
		stage.setScene(scene);
		stage.show();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	GridPane grd;
	Text lablh;
	ImageView img,img1,img2,img3,img4,img5,logo,img9,img6,img7,imageb;

	public void start() {
		// TODO Auto-generated method stub
		
	}

}
