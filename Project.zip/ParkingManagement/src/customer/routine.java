package customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.spi.DirStateFactory.Result;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class routine {
	
	Connection conn,conn1;
	PreparedStatement pst,pst1;
	public routine()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			conn1=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stage=new Stage();
		grd=new GridPane();
		logo=new ImageView(new Image(login.class.getResourceAsStream("routineentry.png")));
		vno=new ComboBox<String>();
		lst=new ListView<Integer>();
		tw=new RadioButton("2-Wheeler");
		fw=new RadioButton("4-Wheeler");
		lablh=new Text("Routine Entry");
		lablf=new Text("Floors");
		lablf.setFill(Color.BLUE);
		lablf.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablm=new Text("Mobile No.");
		lablm.setFill(Color.BLUE);
		lablm.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lables=new Text("Empty Slots");
		lables.setFill(Color.BLUE);
		lables.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablt=new Text("Type");
		lablt.setFill(Color.BLUE);
		lablt.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		btns=new Button("Done");
		btns.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnf=new Button("Fetch");
		btnf.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		lablv=new Text("Vehicle No.");
		lablv.setFill(Color.BLUE);
		lablv.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		txtv=new TextField();
		txtm=new TextField();
		txtes=new TextField();
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,22));
		grd.setVgap(20);
		grd.setPadding(new Insets(20));
		grd.setAlignment(Pos.TOP_CENTER);
		tw.setTextFill(Color.BLUE);
		fw.setTextFill(Color.BLUE);
		floor=new ComboBox<Integer>();
		ArrayList<Integer> lst=new ArrayList<Integer>();
		for(int i=1;i<7;i++)
		{
			lst.add(i);
		}
		floor.getItems().addAll(lst);
		floor.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		vno.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		dofetchvno();
		ToggleGroup tg=new ToggleGroup();
		tw.setToggleGroup(tg);
		fw.setToggleGroup(tg);
		grd.setStyle("-fx-background-color:ALICEBLUE");
		logo.setFitWidth(400);
		grd.setConstraints(logo, 0, 0, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10,0,0,20));
		grd.getChildren().add(logo);
		
		grd.setConstraints(lablv, 0, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(lablv);
		
		grd.setConstraints(vno, 1, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(vno);
		
		grd.setConstraints(btnf, 2, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(btnf);
		
		grd.setConstraints(lablt, 0, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(lablt);
		
		grd.setConstraints(tw, 1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(tw);
		
		grd.setConstraints(fw, 2, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(fw);
		
		grd.setConstraints(lablm, 0, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(lablm);
		
		grd.setConstraints(txtm, 1, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(txtm);
		
		grd.setConstraints(lablf, 0, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(lablf);
		
		grd.setConstraints(floor, 1, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(floor);
		
		grd.setConstraints(lables, 0, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(lables);
		
		grd.setConstraints(txtes, 1, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(txtes);
		
		grd.setConstraints(btns, 0, 6, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(10));
		grd.getChildren().add(btns);
		
		btnf.setOnAction(e->dofetch());
		btns.setOnAction(e->dosave());
		
		Scene scene=new Scene(grd,500,500);
		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	
	Text lablh,lablv,lablt,lablm,lablf,lables;
	TextField txtv,txtm,txtes;
	ComboBox<Integer> floor;
	ComboBox<String> vno;
	Button btns,btnf;
	RadioButton tw,fw;
	GridPane grd;
	ListView<Integer> lst;
	String rbtn="";
	ImageView logo;
	int st=0;
	Stage stage;
	public void start() throws Exception {
		// TODO Auto-generated method stub
		
	}
	void dofetchvno()
	{
		try {
			pst=conn.prepareStatement("select vno from customer");
			ResultSet rs=pst.executeQuery();
			ArrayList<String> lst=new ArrayList<String>();
			while(rs.next())
			{
				String s=rs.getString("vno");
				lst.add(s);
			}
			vno.getItems().addAll(lst);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	void dosave1()
	{
		String rbtn="";
		if(tw.isSelected())
		{
			rbtn="2-Wheeler";
		}
		if(fw.isSelected())
		{
			 rbtn="4-Wheeler";
		}
		try {
			pst=conn.prepareStatement("insert into history values (?,?,?,curdate(),curtime(),?,?,?,?,?)");
			pst.setString(1, vno.getSelectionModel().getSelectedItem());
			pst.setString(2, txtm.getText());
			pst.setString(3, rbtn);
			pst.setInt(4, floor.getSelectionModel().getSelectedItem());
			pst.setDate(5, null);
			pst.setTime(6, null);
			pst.setInt(7, st);
			pst.setInt(8, 0);
			int k=pst.executeUpdate();
			if(k==0)
			{
				System.out.println("Record not Saved");
			}
			else
			{				
				String sms=SST_SMS.bceSunSoftSend("8556069215", "Car has been parked"+"\n Vehicle No : "+vno.getSelectionModel().getSelectedItem()+"\n Floor No: "+floor.getSelectionModel().getSelectedItem());
				System.out.println(sms);
				Alert alert=new Alert(AlertType.INFORMATION);
				alert.setContentText("Record Saved");
				alert.show();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void dofetch()
	{
		try {
			
			pst=conn.prepareStatement("select * from customer where vno=?");
			pst.setString(1,vno.getSelectionModel().getSelectedItem());
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
			{ 
				String mobi=rs.getString("mobile");
				String rbtn24=rs.getString("rbtn");
				
					txtm.setText(mobi);
					if(rbtn24.equals("2-Wheeler"))
					{
						tw.setSelected(true);
					}
					if(rbtn24.equals("4-Wheeler"))
					{
						fw.setSelected(true);
					}
					
			}
			else
			{
				Alert alert=new Alert(AlertType.INFORMATION);
				alert.setContentText("Invalid ID");
				alert.show();
			}
			dofetch2();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	void dofetch2()
	{
		if(tw.isSelected()==true)
		{
			rbtn="2-Wheeler";
		}
		else
		if(fw.isSelected()==true)
		{
			 rbtn="4-Wheeler";
		}
		try {
			pst1=conn.prepareStatement("select * from plan where rbtn=?");
			pst1.setString(1,rbtn);
			ResultSet rs1=pst1.executeQuery();
			ArrayList<Integer> lst=new ArrayList<Integer>();
			if(tw.isSelected()==true)
			{
				floor.getItems().clear();
				while(rs1.next())
				{ 
					int fs=rs1.getInt("floor");
					lst.add(fs);
				}
				floor.getItems().addAll(lst);
			}
			else
			if(fw.isSelected()==true)
			{
				floor.getItems().clear();
				while(rs1.next())
				{ 
					int fs=rs1.getInt("floor");
					lst.add(fs);
				}
				floor.getItems().addAll(lst);
			}
			floor.setOnAction(e->doupdate());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void dosave()
	{
		try {
			pst=conn.prepareStatement("update plan set booked=booked+1 where floor=?");
			pst.setInt(1, floor.getSelectionModel().getSelectedItem());
			System.out.println("SAVED");
			int k=pst.executeUpdate();
			if(k==0)
			{
				System.out.println("Record not Updated");
			}
			else
			{
				Alert alert=new Alert(AlertType.INFORMATION);
				alert.setContentText("Vehicle Entered");
				alert.show();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		dosave1();
	}
	String tos="";
	int b;
	void doupdate()
	{
		int f=floor.getSelectionModel().getSelectedItem();
		System.out.println(""+f);
		try {
			pst=conn.prepareStatement("select * from plan where floor=?");
			pst.setInt(1, f);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				 tos=rs.getString("tslot");
				 b=rs.getInt("booked");
			}
			System.out.println(""+b);
			System.out.println(tos);
			int t=Integer.parseInt(tos);
			int e=t-b;
			if(e==0)
			{
				Alert alert=new Alert(AlertType.INFORMATION);
				alert.setContentText("All slots on this floor are booked");
				alert.show();
			}
			else
			{
				txtes.setText(""+e);
				st=1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
