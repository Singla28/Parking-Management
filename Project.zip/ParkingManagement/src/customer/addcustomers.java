package customer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class addcustomers  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	Connection conn;
	PreparedStatement pst,pst1;
	Text lablh,lablm,lablfn,lablln,labla,lablp,lablv,lable,lablc,lablt;
	TextField txtm,txtfn,txtln,txtp,txtv,txte,txtc;
	TextArea txta;
	GridPane grd;
	RadioButton tw,fw;
	Button btnb,btnn,btnu,btns,btnd,btnse;
	ImageView pic,logo;
	Image img;
	FileChooser fi;
	Stage stage;
	public addcustomers()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//========================================================================================
		
		stage=new Stage();
		grd=new GridPane();
		
		lablh=new Text("Customer Console");
		lablm=new Text("Mobile No.");
		lablm.setFill(Color.BLUE);
		lablm.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablfn=new Text("First Name");
		lablfn.setFill(Color.BLUE);
		lablfn.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));

		lablln=new Text("Last Name");
		lablln.setFill(Color.BLUE);
		lablln.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));

		txtm=new TextField();
		txtfn=new TextField();
		txtln=new TextField();
		txta=new TextArea();
		txtp=new TextField();
		labla=new Text("Address");
		labla.setFill(Color.BLUE);
		labla.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));

		lablp=new Text("Pic");
		lablp.setFill(Color.BLUE);
		lablp.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));

		lablv=new Text("Vehicle No.");
		lablv.setFill(Color.BLUE);
		lablv.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));

		lable=new Text("E-mail");
		lable.setFill(Color.BLUE);
		lable.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));

		txte=new TextField();
		txtv=new TextField();
		txtc=new TextField();
		lablc=new Text("City");
		lablc.setFill(Color.BLUE);
		lablc.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));

		btnn=new Button("New");
		btns=new Button("Save");
		btnu=new Button("Update");
		btnd=new Button("Delete");
		btnse=new Button("Search");
		lablt=new Text("Type");
		lablt.setFill(Color.BLUE);
		lablt.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));

		logo=new ImageView(new Image(login.class.getResourceAsStream("customerconsole.png")));
		fi=new FileChooser();
		try {
			pic=new ImageView(new Image(new FileInputStream(new File("adduser.png"))));
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		txta.setPrefHeight(50);
		txta.setPrefWidth(50);

		txte.setPromptText("                @gmail.com");
		//txte.setAlignment(Pos.CENTER_LEFT);
		txtm.setPromptText("(+91)-1234567890");
		txtfn.setPromptText("First Name");
		txtln.setPromptText("Last Name");
		tw=new RadioButton("2- Wheeler");
		fw=new RadioButton("4-Wheeler");
		btnb=new Button("Browse");
		tw.setTextFill(Color.BLUE);
		fw.setTextFill(Color.BLUE);
		ToggleGroup tg=new ToggleGroup();
		tw.setToggleGroup(tg);
		fw.setToggleGroup(tg);
		grd.setAlignment(Pos.TOP_CENTER);
		grd.setHgap(10);
		//grd.setVgap(20);
		
		grd.setConstraints(logo, 0, 0, 4, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20,0,0,50));
		grd.getChildren().add(logo);
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,22));
		grd.setGridLinesVisible(false);
		
		grd.setConstraints(lablm, 0, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablm);
		
		grd.setConstraints(txtm, 1, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtm);
		
		grd.setConstraints(btnse, 2, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnse);
		
		grd.setConstraints(lablfn, 0, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablfn);
		
		grd.setConstraints(txtfn, 1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtfn);
		
		grd.setConstraints(lablln, 2, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablln);
		
		grd.setConstraints(txtln, 3, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtln);
		
		grd.setConstraints(labla, 0, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labla);
		
		grd.setConstraints(txta, 1, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txta);
		
		grd.setConstraints(lablc, 0, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablc);
		
		grd.setConstraints(txtc, 1, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtc);
		
		grd.setConstraints(lablp, 0, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablp);
		
		grd.setConstraints(btnb, 2, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnb);
		
		pic.setFitHeight(80);
		pic.setFitWidth(80);
		grd.setConstraints(pic, 1, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(pic);
		
		grd.setConstraints(lablv, 0, 6, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablv);
		
		grd.setConstraints(txtv, 1, 6, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtv);
		
		grd.setConstraints(lable, 0, 7, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lable);
		
		grd.setConstraints(txte, 1, 7, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txte);
		
		grd.setConstraints(lablt, 0, 8, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablt);
		
		grd.setConstraints(tw, 1, 8, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(tw);
		
		grd.setConstraints(fw, 2, 8, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(fw);
		
		grd.setConstraints(btnn, 0, 9, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnn);
		
		grd.setConstraints(btns, 1, 9, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btns);
		
		grd.setConstraints(btnu, 2, 9, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnu);
		
		grd.setConstraints(btnd, 3, 9, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnd);
		
		ImageView icon1=new ImageView(new Image(addcustomers.class.getResourceAsStream("favicon.png")));
		btnn.setGraphic(icon1);
		icon1.setFitHeight(30);
		icon1.setFitWidth(25);
		ImageView icon2=new ImageView(new Image(addcustomers.class.getResourceAsStream("add.png")));
		icon2.setFitHeight(30);
		icon2.setFitWidth(25);
		btnn.setGraphic(icon2);
		ImageView icon3=new ImageView(new Image(addcustomers.class.getResourceAsStream("delete.png")));
		btnd.setGraphic(icon3);
		ImageView icon4=new ImageView(new Image(addcustomers.class.getResourceAsStream("favicon.png")));
		icon4.setFitHeight(30);
		icon4.setFitWidth(25);
		btnu.setGraphic(icon4);
		icon3.setFitHeight(30);
		icon3.setFitWidth(25);
		btnn.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btns.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnu.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnd.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnse.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnb.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");

		grd.setStyle("-fx-background-color:ALICEBLUE");
		btnn.setOnAction(e->donew());
		btns.setOnAction(e->dosave());
		btnu.setOnAction(e->doupdate());
		btnse.setOnAction(e->dosearch());
		btnd.setOnAction(e->dodelete());
		btnb.setOnAction(e->{
			fi.setTitle("File");
			File select=fi.showOpenDialog(stage);
			if(select==null)
			{
				try {
					pic.setImage(new Image(new FileInputStream("adduser.png")));
					String s1=new String("");
					txtp.setText(s1);
					return;
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			FileInputStream fis;
			
			try {
				String s1=new String(select.getAbsolutePath());
				txtp.setText(s1);
				img=new Image(new FileInputStream(select.getAbsolutePath()));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			pic.setImage(img);
		});
		
		Scene scene=new Scene(grd,850,800);
		stage.setScene(scene);
		stage.show();
		
		
	}
	public void start() throws Exception {
		// TODO Auto-generated method stub
		
	}
		void dosearch()
		{
			//System.out.println(txtm.getText());
			try {
				pst=conn.prepareStatement("select * from customer where mobile=?");
				pst.setString(1,txtm.getText());
				ResultSet rs=pst.executeQuery();
				
				if(rs.next())
				{ 
					//String mobi=rs.getString("mobile");
					String finame=rs.getString("fname");
					String laname=rs.getString("lname");
					String picpath=rs.getString("path");
					String vehno=rs.getString("vno");
					String emailid=rs.getString("email");
					String cit=rs.getString("city");
					String add=rs.getString("address");
					String rbtn24=rs.getString("rbtn");
					//System.out.println(finame);
					    txtfn.setText(finame);
						txtln.setText(laname);
						txtp.setText(picpath);
						txta.setText(add);
						txtv.setText(vehno);
						txte.setText(emailid);
						txtc.setText(cit);
						
						if(rbtn24.equals("2-Wheeler"))
						{
							tw.setSelected(true);
						}
						if(rbtn24.equals("4-Wheeler"))
						{
							fw.setSelected(true);
						}
				}
				else
				{
					/*System.out.println("Invalid ID");*/
					Alert alert=new Alert(AlertType.INFORMATION);
					alert.setContentText("Invalid ID");
					alert.show();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		void doupdate()
		{
			String mob=txtm.getText();
			String firstn=txtfn.getText();
			String lastn=txtln.getText();
			String path=txtp.getText();
			String vno=txtv.getText();
			String email=txte.getText();
			String city=txtc.getText();
			String address=txta.getText();
			String rbtn="";
			if(tw.isSelected()==true)
			{
				rbtn="2-Wheeler";
			}
			if(fw.isSelected()==true)
			{
				 rbtn="4-Wheeler";
			}
			
			try {
				pst=conn.prepareStatement("update customer set fname=?,lname=?,path=?,vno=?,email=?,city=?,address=?,rbtn=? where mobile=?");
				pst.setString(1, firstn);
				pst.setString(2, lastn);
				pst.setString(3, path);
				pst.setString(4, vno);
				pst.setString(5, email);
				pst.setString(6, city);
				pst.setString(7, address);
				pst.setString(8, rbtn);
				pst.setString(9,mob);
				int k=pst.executeUpdate();
				if(k==0)
				System.out.println("Record Updated..");
				else
				{
					Alert alert=new Alert(AlertType.INFORMATION);
					alert.setContentText("Your data has been Updated");
					alert.show();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}
		void donew()
		{
			txtm.setText("");
			txtfn.setText("");
			txtln.setText("");
			txta.setText("");
			try {
				pic.setImage(new Image(new FileInputStream("adduser.png")));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			txtv.setText("");
			txte.setText("");
			tw.setSelected(false);
			fw.setSelected(false);
			txtc.setText("");
		}
		//To check whether all are filled or not
		void dosave()
		{
			String mob=txtm.getText();
			String firstn=txtfn.getText();
			String lastn=txtln.getText();
			String path=txtp.getText();
			String vno=txtv.getText();
			String email=txte.getText();
			String city=txtc.getText();
			String address=txta.getText();
			String rbtn="";
			if(tw.isSelected()==true)
			{
				rbtn="2-Wheeler";
			}
			if(fw.isSelected()==true)
			{
				 rbtn="4-Wheeler";
			}
			
			try {
				pst=conn.prepareStatement("insert into customer values (?,?,?,?,?,?,?,?,?)");
				pst.setString(1, mob);
				pst.setString(2, firstn);
				pst.setString(3, lastn);
				pst.setString(4, path);
				pst.setString(5, vno);
				pst.setString(6, email);
				pst.setString(7, city);
				pst.setString(8, address);
				pst.setString(9, rbtn);
				int k=pst.executeUpdate();
				if(k==0)
				System.out.println("Record Saved..");
				else
				{
					Alert alert=new Alert(AlertType.INFORMATION);
					alert.setContentText("Your data has been saved");
					alert.show();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			}
		void dodelete()
		{			
			if(txtm.getText().equals(""))
			{
				Alert alert=new Alert(AlertType.INFORMATION);
				alert.setContentText("Enter mobile no.");
				alert.show();
			}
			else
			{
			try {
				pst=conn.prepareStatement("delete from customer where mobile=?");
				pst.setString(1, txtm.getText());
				int k=pst.executeUpdate();
				if(k==0)
				System.out.println("Record not Deleted..");
				else
				{
					txtm.setText("");
					Alert alert=new Alert(AlertType.INFORMATION);
					alert.setContentText("Entry has been deleted");
					alert.show();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			}	
		}

}
