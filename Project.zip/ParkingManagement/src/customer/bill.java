package customer;

import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.xml.transform.Result;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class bill {

	Connection conn;
	PreparedStatement pst;
	public bill()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//================
		stage=new Stage();
		grd=new GridPane();
		logo=new ImageView(new Image(login.class.getResourceAsStream("vehicleexit.png")));
		btnb=new Button("Bill");
		btnpb=new Button("Print Bill");
		lablh=new Text("BILL GENERATION");
		lablv=new Text("Vehicle No.");
		lablv.setFill(Color.BLUE);
		lablv.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablt=new Text("Type");
		lablt.setFill(Color.BLUE);
		lablt.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablm=new Text("Mobile No.");
		lablm.setFill(Color.BLUE);
		lablm.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		labla=new Text("Amount");
		labla.setFill(Color.BLUE);
		labla.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		labl2=new Text("2-Wheeler Cost");
		labl2.setFill(Color.BLUE);
		labl2.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		labl4=new Text("4-Wheeler Cost");
		labl4.setFill(Color.BLUE);
		labl4.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablf=new Text("Floor");
		lablf.setFill(Color.BLUE);
		lablf.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		txt2=new TextField();
		txt4=new TextField();
		txtf=new TextField();
		txtf.setPromptText("Floor No.");
		txtt=new TextField();
		txtm=new TextField();
		txta=new TextField();
		tw=new RadioButton("2-Wheeler");
		fw=new RadioButton("4-Wheeler");
		ToggleGroup tg=new ToggleGroup();
		tw.setToggleGroup(tg);
		fw.setToggleGroup(tg);
		tw.setTextFill(Color.BLUE);
		fw.setTextFill(Color.BLUE);
		vno=new ComboBox<String>();
		//ArrayList<String> lst=new ArrayList<String>(Arrays.asList(""));
		grd.setStyle("-fx-background-color:ALICEBLUE");
		grd.setAlignment(Pos.CENTER);
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,22));
		lablt.setFont(Font.font("Arial",FontWeight.BOLD,18));
		lablv.setFont(Font.font("Arial",FontWeight.BOLD,18));
		lablm.setFont(Font.font("Arial",FontWeight.BOLD,18));
		labla.setFont(Font.font("Arial",FontWeight.BOLD,18));
		lablf.setFont(Font.font("Arial",FontWeight.BOLD,18));
		vno.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		grd.setConstraints(logo, 0, 0, 3, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(logo);
		
		grd.setConstraints(lablt, 0, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablt);
		
		grd.setConstraints(tw, 1, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(tw);
		
		grd.setConstraints(fw, 2, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(fw);
		
		grd.setConstraints(lablv, 0, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablv);
		
		grd.setConstraints(vno, 1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(vno);
		
		grd.setConstraints(lablm,0, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablm);
		
		grd.setConstraints(txtm,1, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtm);
		
		grd.setConstraints(lablf,0, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablf);
		
		grd.setConstraints(txtf,1, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtf);
		
		grd.setConstraints(labl2,0, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labl2);
		
		grd.setConstraints(txt2,1, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txt2);
		
		grd.setConstraints(labl4,2, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labl4);
		
		grd.setConstraints(txt4,3, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txt4);
		
		grd.setConstraints(btnb,0, 6, 3, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnb);
		btnb.setAlignment(Pos.CENTER);
		
		btnb.setOnAction(e->dobill());
		vno.setOnAction(e->dofetch2());
		tw.setOnAction(e->dofetch());
		fw.setOnAction(e->dofetch());
		
		btnb.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		btnpb.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		Scene scene=new Scene(grd,650,600);
		stage.setScene(scene);
		stage.show();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	Text lablh,lablv,lablt,lablm,labla,labl2,labl4,lablf;
	Button btnb,btnpb;
	TextField txtt,txtm,txta,txtf,txt2,txt4;
	GridPane grd;
	ComboBox<String> vno;
	RadioButton tw,fw;
	ImageView logo;
	Stage stage;
	Label jobstatus=new Label();
	public void start() throws Exception {
		
	}
	String b,w,i,o,v;
	
	float r;
	void dobill()
	{
		String rate="";
		if(tw.isSelected())
		{
			rate=txt2.getText();
			w="2-Wheeler";
		}
		else
		if(fw.isSelected())
		{
			w="4-Wheeler";
			rate=txt4.getText();
		}
		b=txta.getText();
		
		v=vno.getSelectionModel().getSelectedItem();
		
		try {
			pst=conn.prepareStatement("select outdate,indate from history where vno=?");
			pst.setString(1, vno.getSelectionModel().getSelectedItem());
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				String i=rs.getDate("indate").toString();
				String o=rs.getDate("outdate").toString();
			}
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		r=Float.parseFloat(rate);
		grd.setConstraints(labla,0, 7, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labla);
		
		grd.setConstraints(txta,1, 7, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txta);
		
		grd.setConstraints(btnpb,0, 8, 3, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnpb);
		
		btnpb.setOnAction(e->{
			printbill obj=new printbill(b,w,i,o,v);
		});
		try {
			pst=conn.prepareStatement("update history set outdate=curdate(),outtime=curtime() where vno=? and status=1");
			pst.setString(1, vno.getSelectionModel().getSelectedItem());
			int k=pst.executeUpdate();
			if(k==0)
			{
				System.out.println("Record not updated");
			}
			else
			{
				Alert alert=new Alert(AlertType.INFORMATION);
				alert.setContentText("Vehicle gone");
				alert.show();
			}
			doupdatebooked();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	void printSetup(Node node,Stage owner)
	{
		PrinterJob job=PrinterJob.createPrinterJob();
		if(job==null)
		{
			return;
		}
		if(job.showPrintDialog(owner))
		{
			print(job,node);
		}
	}
	void print(PrinterJob job,Node node)
	{
		jobstatus.textProperty().bind(job.jobStatusProperty().asString());
		if(job.printPage(node))
		{
			job.endJob();
		}
	}
	void doupdatebooked()
	{
		System.out.println(txtf.getText());
		int f=Integer.parseInt(txtf.getText());
		try {
			pst=conn.prepareStatement("update plan set booked=booked-1 where floor=? and booked>=0 ");
			pst.setInt(1, f);
			int k=pst.executeUpdate();
			if(k==0)
			{
				System.out.println("Record not updated");
			}
			else
			{
				System.out.println("Record Updated");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		docalcbill();
	}
	float am;
	void docalcbill()
	{
		int d=0;
		try {
			pst=conn.prepareStatement("select datediff(outdate,indate) as diff from history where vno=?");
			pst.setString(1, vno.getSelectionModel().getSelectedItem());
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				d=rs.getInt("diff");
			}
			System.out.println(""+d);
			
			if(d==0)
			{
				am=r;
			}
			else
				if(d>0)
			{
				am=r*d;
			}
			txta.setText(""+am);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		doupdatebill();
	}
	void doupdatebill()
	{
		int fl=Integer.parseInt(txtf.getText());
		try {
			pst=conn.prepareStatement("update history set bill=? , status=0 where vno=? and status=1 and floor=?");
			pst.setFloat(1, am);
			pst.setString(2, vno.getSelectionModel().getSelectedItem());
			pst.setInt(3, fl);
			int k=pst.executeUpdate();
			if(k==0)
			{
				System.out.println("Bill not Updated");
			}
			else
			{
				System.out.println("Bill updated");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void dofetch()
	{
		String rbtn="";
		if(tw.isSelected())
		{
			rbtn="2-Wheeler";
		}
		else
		if(fw.isSelected())
		{
			rbtn="4-Wheeler";
		}
		
		try {
			pst=conn.prepareStatement("select distinct vno from history where wheeler=? and status=1");
			pst.setString(1, rbtn);
			ResultSet rs=pst.executeQuery();
			ArrayList<String> lst=new ArrayList<String>();
			if(rbtn.equals("2-Wheeler"))
			{
					vno.getItems().clear();
				while(rs.next())
				{
					String veh=rs.getString("vno");
					lst.add(veh);
				}
				vno.getItems().addAll(lst);
			}
			else
			if(rbtn.equals("4-Wheeler"))
				{
					vno.getItems().clear();
				while(rs.next())
				{
					String veh=rs.getString("vno");
					lst.add(veh);
				}
				vno.getItems().addAll(lst);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void dofetch2()
	{
		try {
			pst=conn.prepareStatement("select mobile from customer where vno=?");
			pst.setString(1, vno.getSelectionModel().getSelectedItem());
			ResultSet rs=pst.executeQuery();
			String mob="";
			if(rs.next())
			{
				mob=rs.getString("mobile");
			}
			txtm.setText(mob);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dofetch3();
	}	
	void dofetch3()
	{
		try {
			int f=0;
			pst=conn.prepareStatement("select floor from history where vno=?");
			pst.setString(1, vno.getSelectionModel().getSelectedItem());
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				 f=rs.getInt("floor");
			}
			txtf.setText(""+f);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
