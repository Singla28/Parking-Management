package customer;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Aboutus {
	
	public Aboutus()
	{
		stage=new Stage();
		grd=new GridPane();
		lablh=new Text("ABOUT US");
		lablm=new Text("About the Developer : ");
		labls=new Text("Under The Guidance of : ");
		txtm=new Text("Deepanshu Singla,persuading " +"\n" +"B.tech in Computer Science \nat JUIT,Waknaghat Solan.");
		txts=new Text("Rajesh K. Bansal \n is the founder and owner of \n Bangalore Computer Education \n and training and development head \n at Sun - Soft Technologies");
		logo=new ImageView(new Image(Aboutus.class.getResourceAsStream("aboutus.png")));
		imgm=new ImageView(new Image(Aboutus.class.getResourceAsStream("me.png")));
		imgs=new ImageView(new Image(Aboutus.class.getResourceAsStream("sir.png")));
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,36));
		lablm.setFont(Font.font("Arial",FontWeight.BOLD,22));
		labls.setFont(Font.font("Arial",FontWeight.BOLD,22));
		lablm.setFill(Color.BLUE);
		lablm.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,26));
		labls.setFill(Color.BLUE);
		labls.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,26));
		txtm.setFill(Color.BLUE);
		txtm.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		txts.setFill(Color.BLUE);
		txts.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		
		grd.setVgap(20);
		
		grd.setConstraints(logo,0, 0, 3, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(logo);
		imgm.setFitHeight(200);
		imgm.setFitWidth(200);
		grd.setConstraints(imgm,0, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(imgm);
		grd.setConstraints(lablm,0, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablm);
		grd.setConstraints(txtm,1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtm);
		
		grd.setConstraints(labls,0, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(labls);
		imgs.setFitHeight(200);
		imgs.setFitWidth(200);
		grd.setConstraints(imgs,0, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(imgs);
		
		grd.setConstraints(txts,1, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txts);
		
		grd.setAlignment(Pos.CENTER);
		grd.setStyle("-fx-background-color:ALICEBLUE");
		Scene scene =new Scene(grd,800,800);
		stage.setScene(scene);
		stage.show();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	Stage stage;
	GridPane grd;
	Text lablh,lablm,labls,txtm,txts;
	ImageView logo,imgm,imgs;
	public void start() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
