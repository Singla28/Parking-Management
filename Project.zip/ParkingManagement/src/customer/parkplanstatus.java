package customer;

import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class parkplanstatus{
	Connection conn;
	PreparedStatement pst;
	
	public parkplanstatus()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","bce");
			System.out.println("Connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stage=new Stage();
		grd=new GridPane();
		logo=new ImageView(new Image(login.class.getResourceAsStream("parkingstatus.png")));
		floor=new ComboBox<Integer>();
		lablh=new Text("PARKING PLAN STATUS");
		lablf=new Text("Floors");
		lablf.setFill(Color.BLUE);
		lablf.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablts=new Text("Total Slots");
		lablts.setFill(Color.BLUE);
		lablts.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablo=new Text("Occupied Slots");
		lablo.setFill(Color.BLUE);
		lablo.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		lablfr=new Text("Free Slots");
		lablfr.setFill(Color.BLUE);
		lablfr.setFont(Font.font("SANS_SERIF",FontWeight.BOLD,16));
		txtts=new TextField();
		txto=new TextField();
		txtf=new TextField();
		btnf=new Button("Fetch All");
		floor=new ComboBox<Integer>();
		floor.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		tbl=new TableView<parkplan>();
		btnf.setStyle("-fx-font: 16 arial; -fx-base: #b6e7c9;");
		
		TableColumn<parkplan, String> col1=new TableColumn<parkplan, String>("Floor");
		col1.setCellValueFactory(new PropertyValueFactory<>("floor"));
		col1.setMinWidth(100);
		
		TableColumn<parkplan, String> col2=new TableColumn<parkplan, String>("Total Slots");
		col2.setCellValueFactory(new PropertyValueFactory<>("tslot"));
		col2.setMinWidth(100);
		
		TableColumn<parkplan, String> col3=new TableColumn<parkplan, String>("Booked");
		col3.setCellValueFactory(new PropertyValueFactory<>("booked"));
		col3.setMinWidth(100);
		
		TableColumn<parkplan, String> col4=new TableColumn<parkplan, String>("Wheeler");
		col4.setCellValueFactory(new PropertyValueFactory<>("rbtn"));
		col4.setMinWidth(100);
		ArrayList<Integer> ary=new ArrayList<Integer>();
		for(int i=1;i<=10;i++)
		{
			ary.add(i);
		}
		floor.getItems().addAll(ary);
		tbl.getColumns().addAll(col1,col2,col3,col4);
		
		btnf.setOnAction(e->tbl.setItems(getrows()));
		
		floor.setOnAction(e->dofetch());
		
		lablh.setFont(Font.font("Arial",FontWeight.BOLD,22));
		grd.setStyle("-fx-background-color:ALICEBLUE");
		grd.setConstraints(logo, 0, 0, 2, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(logo);
		logo.setFitWidth(400);
		grd.setConstraints(lablf, 0, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablf);
		
		grd.setConstraints(floor, 1, 1, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(floor);
		
		grd.setConstraints(lablts, 0, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablts);
		
		grd.setConstraints(txtts, 1, 2, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtts);
		
		grd.setConstraints(lablo, 0, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablo);
		
		grd.setConstraints(txto, 1, 3, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txto);
		
		grd.setConstraints(lablfr, 0, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(lablfr);
		
		grd.setConstraints(txtf, 1, 4, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(txtf);
		
		grd.setConstraints(btnf, 0, 5, 1, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(btnf);
		
		grd.setConstraints(tbl, 0, 6, 5, 1, HPos.CENTER, VPos.CENTER, null, null, new Insets(20));
		grd.getChildren().add(tbl);
		
		grd.setAlignment(Pos.CENTER);
		
		Scene scene= new Scene(grd,600,600);
		stage.setScene(scene);
		stage.show();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	Stage stage;
	GridPane grd;
	ComboBox<Integer> floor;
	Text lablh,lablf,lablts,lablo,lablfr;
	TextField txtts,txto,txtf;
	Button btnf;
	TableView<parkplan> tbl;
	ImageView logo;
	
	public void start() throws Exception {
		// TODO Auto-generated method stub
		
	}
	ObservableList<parkplan> getrows()
	{
		
		ObservableList<parkplan> lst=FXCollections.observableArrayList();
		try {
			pst=conn.prepareStatement("select * from plan ");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				parkplan ref=new parkplan(rs.getInt("floor"),rs.getString("tslot"),rs.getInt("booked"),rs.getString("rbtn"));
				lst.add(ref);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
	}
	void dofetch()
	{
		String t="";
		int b=0;
		int f=floor.getSelectionModel().getSelectedItem();
		try {
			pst=conn.prepareStatement("select * from plan where floor=?");
			pst.setInt(1, f);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				t=rs.getString("tslot");
				b=rs.getInt("booked");
			}
			int tot=Integer.parseInt(t);
			int free=tot-b;
			txtts.setText(t);
			txto.setText(""+b);
			txtf.setText(""+free);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
